Curiosity_Nano.dra
