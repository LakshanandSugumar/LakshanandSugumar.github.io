# serial_pair_test.py
import serial, time

PORT = "COM10"   # set to your adapter COM
BAUD = 9600
TIMEOUT = 0.1

def send_pair(x_byte, y_byte):
    try:
        s = serial.Serial(PORT, BAUD, timeout=TIMEOUT)
    except Exception as e:
        print("Open error:", e); return
    print("Opened", PORT)
    time.sleep(0.1)
    # flush incoming
    while s.in_waiting:
        s.read(s.in_waiting)
    print("Sending bytes:", x_byte, y_byte)
    s.write(bytes([x_byte]))
    time.sleep(0.05)
    s.write(bytes([y_byte]))
    s.flush()
    print("Sent. Waiting up to 3s for any reply...")
    deadline = time.time() + 3.0
    buf = b""
    while time.time() < deadline:
        if s.in_waiting:
            chunk = s.read(s.in_waiting)
            buf += chunk
            print("RECV (raw):", buf)
            try:
                print("RECV (ascii):", buf.decode('ascii', errors='replace'))
            except:
                pass
        time.sleep(0.05)
    if not buf:
        print("No reply received.")
    s.close()

if __name__ == "__main__":
    # Use the bytes you saw earlier
    send_pair(25, 149)
