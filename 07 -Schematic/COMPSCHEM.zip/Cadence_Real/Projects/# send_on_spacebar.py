import numpy as np
import cv2
import serial
import time
import math

ser = serial.Serial()
ser.baudrate = 9600
ser.port = 'COM10'


cap = cv2.VideoCapture(0)

cm_to_pixel = 21.6/640.0

ThetaZ = -4.0
ThetaY = 180.0

Dx = 12.7-0.5
Dy = -0.9+8.2-9+0.3
Dz = 0.0

ThetaZ = np.deg2rad(ThetaZ)
ThetaY = np.deg2rad(ThetaY)

R0_1 = [[np.cos(ThetaZ),-np.sin(ThetaZ),0],[np.sin(ThetaZ),np.cos(ThetaZ),0],[0,0,1]]
R1_2 = [[np.cos(ThetaY),0,np.sin(ThetaY)],[0,1,0],[-np.sin(ThetaY),0,np.cos(ThetaY)]]

R0_2 = np.dot(R1_2,R0_1)

D0_C = [[Dx],[Dy],[Dz]] 
H0_C = np.concatenate((R0_2,D0_C),1)
H0_C = np.concatenate((H0_C,[[0,0,0,1]]),0)

End = False

while(1):
    breakOut = 0
    while(1):
        _,frame = cap.read()

        gray_image_1 = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)

        cv2.imshow('background',gray_image_1)
        breakOut += 1
        cv2.waitKey(5)
        if(breakOut >= 100):
            break

    Stability = 0
    Prev_X = 0
    Prev_Y = 0

    ser.open()
    ser.write(bytearray([1]))
    ser.close()

    while(1):
        _,frame = cap.read()
        gray_image_2 = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)

        #cv2.imshow('foreground',gray_image_2)

        Difference = np.absolute(np.matrix(np.int16(gray_image_1))-np.matrix(np.int16(gray_image_2)))

        Difference[Difference > 255] = 255

        Difference = np.uint8(Difference)

        BW = Difference
        BW[BW<= 100]=0
        BW[BW>100]=255

        column_sums = np.matrix(np.sum(Difference,0))
        column_numbers = np.matrix(np.arange(640))
        column_mult = np.multiply(column_sums, column_numbers)
        column_total = np.sum(column_mult)
        total_total = np.sum(np.sum(Difference))
        BW_column_location = column_total/total_total
        BW_column_location = np.nan_to_num(BW_column_location, nan=0)

        #print('Object column ("X") location: ',BW_column_location)

        row_sums = np.matrix(np.sum(Difference,1)).T
        row_numbers = np.matrix(np.arange(480))
        row_mult = np.multiply(row_sums,row_numbers)
        row_total = np.sum(row_mult)
        BW_row_location = row_total/total_total
        BW_row_location = np.nan_to_num(BW_row_location, nan=0)

        X_Location = BW_column_location*cm_to_pixel

        #print ('Object row ("Y") location: ',BW_row_location)

        color = (255,255,255)
        thickness = 1

        diff_x_location = np.uint16(BW_column_location)
        diff_y_location = np.uint16(BW_row_location)

        BW = cv2.line(BW, (diff_x_location, 0), (diff_x_location, 480), color, thickness)
        BW = cv2.line(BW, (0, diff_y_location), (640, diff_y_location), color, thickness)

        Y_Location = BW_row_location*cm_to_pixel

        PC = [[X_Location],[Y_Location],[0],[1]]
        P0 = np.dot(H0_C,PC)
        X_BaseFrame = P0[0]
        Y_BaseFrame = P0[1]

        X_BaseFrame = np.round(X_BaseFrame,3)
        Y_BaseFrame = np.round(Y_BaseFrame,3)


        difference_text = 'Addink - BW with Center'
        unit_Text = f"x:{X_BaseFrame}, y:{Y_BaseFrame} "
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_size = 0.8
        font_color = (255,255,255)
        font_thickness = 2
        x,y = 10,20
        BW = cv2.putText(BW, difference_text, (x,y), font, font_size, font_color, font_thickness)
        BW = cv2.putText(BW, unit_Text, (x,50), font, font_size, (255,255,255), font_thickness)

        cv2.imshow('Difference w/ Center & Threshold',BW)


        #STABILIZATION DETECTION

        if(X_BaseFrame > -6 and X_BaseFrame < 11):
            if(Y_BaseFrame > 8 and Y_BaseFrame < 15):
                if(abs(Prev_X - X_BaseFrame) < 2 and abs(Prev_Y - Y_BaseFrame) < 2):
                    Stability += 1
                    print(Stability)
                else:
                    Stability = 0
                    Prev_X = X_BaseFrame
                    Prev_Y = Y_BaseFrame

        if(Stability >= 150):
            break
        
        k = cv2.waitKey(5)
        if k == 27:
            End = True
            break


    cv2.destroyAllWindows()
    if(End == True):
        break
    ser.open()
    ser.write(bytearray([int((np.round(X_BaseFrame,1) + 10)*10)]))
    ser.close()
    time.sleep(2)

    ser.open()
    ser.write(bytearray([int((np.round(Y_BaseFrame,1) + 10)*10)]))
    ser.close()
    time.sleep(2)


    ser.open()

    ReadyForAnother = 0
    while(ReadyForAnother == 0):
        ReadyForAnother = ser.read()

    ser.close()